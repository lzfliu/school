CREATE VIEW user_view AS
  SELECT `lzf`.`test_user`.`username` AS `username`
  FROM `lzf`.`test_user`;
