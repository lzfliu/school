CREATE PROCEDURE test(IN username VARCHAR(32), OUT user VARCHAR(512))
  BEGIN
    SET user := NULL;
    SELECT * FROM test_user WHERE test_user.username like  Concat('%',username, '%'); -- this 返回一个结果集
  END;
